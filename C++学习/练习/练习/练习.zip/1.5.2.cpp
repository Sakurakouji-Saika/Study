#include <iostream>
using namespace std;

int main()
{
    for (int i = 0; i < 10000; ++i)
    {
        cout << "�Ұ���!" << i << endl;

    }
    return 0;
}